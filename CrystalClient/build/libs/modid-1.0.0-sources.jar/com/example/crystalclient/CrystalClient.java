package com.example.crystalclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2627;
import net.minecraft.class_2818;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3719;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import java.util.Map;

public class CrystalClient implements ClientModInitializer {

    public static boolean speedEnabled = false;
    public static boolean jumpEnabled  = false;
    public static boolean flyEnabled   = false;
    public static boolean playerEsp    = false;
    public static boolean mobEsp       = false;
    public static boolean chestEsp     = false;
    public static boolean itemEsp      = false;

    private static class_304 speedKey, jumpKey, flyKey;
    private static class_304 playerEspKey, mobEspKey, chestEspKey, itemEspKey;

    @Override
    public void onInitializeClient() {
        speedKey     = reg("speed",     GLFW.GLFW_KEY_R);
        jumpKey      = reg("jump",      GLFW.GLFW_KEY_J);
        flyKey       = reg("fly",       GLFW.GLFW_KEY_F);
        playerEspKey = reg("playeresp", GLFW.GLFW_KEY_Z);
        mobEspKey    = reg("mobesp",    GLFW.GLFW_KEY_X);
        chestEspKey  = reg("chestesp",  GLFW.GLFW_KEY_G);
        itemEspKey   = reg("itemesp",   GLFW.GLFW_KEY_H);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (speedKey.method_1436())     speedEnabled = !speedEnabled;
            if (jumpKey.method_1436())      jumpEnabled  = !jumpEnabled;
            if (flyKey.method_1436()) {
                flyEnabled = !flyEnabled;
                if (client.field_1724 != null) {
                    client.field_1724.method_31549().field_7478 = flyEnabled;
                    if (!flyEnabled) client.field_1724.method_31549().field_7479 = false;
                    client.field_1724.method_7355();
                }
            }
            if (playerEspKey.method_1436()) playerEsp = !playerEsp;
            if (mobEspKey.method_1436())    mobEsp    = !mobEsp;
            if (chestEspKey.method_1436())  chestEsp  = !chestEsp;
            if (itemEspKey.method_1436())   itemEsp   = !itemEsp;

            if (client.field_1724 != null) {
                if (speedEnabled)
                    client.field_1724.method_6092(
                        new class_1293(class_1294.field_5904, 20, 4, false, false));
                if (jumpEnabled)
                    client.field_1724.method_6092(
                        new class_1293(class_1294.field_5913, 20, 4, false, false));
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            class_310 client = class_310.method_1551();
            if (client.field_1687 == null || client.field_1724 == null) return;
            if (context.consumers() == null) return;
            class_4587 matrices = context.matrixStack();
            if (matrices == null) return;
            class_243 cam = context.camera().method_19326();
            class_4588 lines = context.consumers().getBuffer(class_1921.field_21695);

            if (playerEsp) {
                for (class_1657 p : client.field_1687.method_18456()) {
                    if (p == client.field_1724) continue;
                    drawEntityBox(matrices, lines, p, cam, 1f, 0f, 0f);
                }
            }
            if (mobEsp) {
                for (class_1297 e : client.field_1687.method_18112()) {
                    if (e instanceof class_1308 mob)
                        drawEntityBox(matrices, lines, mob, cam, 1f, 1f, 0f);
                }
            }
            if (itemEsp) {
                for (class_1297 e : client.field_1687.method_18112()) {
                    if (e instanceof class_1542 item)
                        drawEntityBox(matrices, lines, item, cam, 0f, 1f, 1f);
                }
            }
            if (chestEsp) {
                int px = (int) client.field_1724.method_23317() >> 4;
                int pz = (int) client.field_1724.method_23321() >> 4;
                for (int cx = px - 8; cx <= px + 8; cx++) {
                    for (int cz = pz - 8; cz <= pz + 8; cz++) {
                        class_2818 chunk = client.field_1687.method_2935().method_21730(cx, cz);
                        if (chunk == null) continue;
                        for (Map.Entry<class_2338, class_2586> entry : chunk.method_12214().entrySet()) {
                            class_2586 be = entry.getValue();
                            if (be instanceof class_2595
                             || be instanceof class_2627
                             || be instanceof class_3719
                             || be instanceof class_2611)
                                drawBlockBox(matrices, lines, entry.getKey(), cam, 0f, 1f, 0f);
                        }
                    }
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1690.field_1842) return;
            int x = 5, y = 5;
            drawContext.method_51433(client.field_1772, "§b§l[CrystalClient]",                     x, y,    0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fSpeed     [R]: " + onOff(speedEnabled), x, y+14, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fJump      [J]: " + onOff(jumpEnabled),  x, y+24, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fFly       [F]: " + onOff(flyEnabled),   x, y+34, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fPlayerESP [Z]: " + onOff(playerEsp),    x, y+44, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fMobESP    [X]: " + onOff(mobEsp),       x, y+54, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fChestESP  [G]: " + onOff(chestEsp),     x, y+64, 0xFFFFFF, true);
            drawContext.method_51433(client.field_1772, "§fItemESP   [H]: " + onOff(itemEsp),      x, y+74, 0xFFFFFF, true);
        });
    }

    private class_304 reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(new class_304(
            "key.crystalclient." + name, class_3675.class_307.field_1668, key, "CrystalClient"
        ));
    }

    private String onOff(boolean v) { return v ? "§aON" : "§cOFF"; }

    private void drawEntityBox(class_4587 m, class_4588 v, class_1297 e, class_243 cam, float r, float g, float b) {
        class_238 box = e.method_5829();
        drawBox(m, v, box.field_1323-cam.field_1352, box.field_1322-cam.field_1351, box.field_1321-cam.field_1350,
                     box.field_1320-cam.field_1352, box.field_1325-cam.field_1351, box.field_1324-cam.field_1350, r, g, b);
    }

    private void drawBlockBox(class_4587 m, class_4588 v, class_2338 pos, class_243 cam, float r, float g, float b) {
        drawBox(m, v, pos.method_10263()-cam.field_1352,   pos.method_10264()-cam.field_1351,   pos.method_10260()-cam.field_1350,
                     pos.method_10263()+1-cam.field_1352, pos.method_10264()+1-cam.field_1351, pos.method_10260()+1-cam.field_1350, r, g, b);
    }

    private void drawBox(class_4587 ms, class_4588 v,
            double x1, double y1, double z1, double x2, double y2, double z2,
            float r, float g, float b) {
        Matrix4f m = ms.method_23760().method_23761();
        float ax=(float)x1,ay=(float)y1,az=(float)z1;
        float bx=(float)x2,by=(float)y2,bz=(float)z2;
        ln(v,m,ax,ay,az,bx,ay,az,r,g,b); ln(v,m,bx,ay,az,bx,ay,bz,r,g,b);
        ln(v,m,bx,ay,bz,ax,ay,bz,r,g,b); ln(v,m,ax,ay,bz,ax,ay,az,r,g,b);
        ln(v,m,ax,by,az,bx,by,az,r,g,b); ln(v,m,bx,by,az,bx,by,bz,r,g,b);
        ln(v,m,bx,by,bz,ax,by,bz,r,g,b); ln(v,m,ax,by,bz,ax,by,az,r,g,b);
        ln(v,m,ax,ay,az,ax,by,az,r,g,b); ln(v,m,bx,ay,az,bx,by,az,r,g,b);
        ln(v,m,bx,ay,bz,bx,by,bz,r,g,b); ln(v,m,ax,ay,bz,ax,by,bz,r,g,b);
    }

    private void ln(class_4588 v, Matrix4f m,
            float x1,float y1,float z1, float x2,float y2,float z2,
            float r, float g, float b) {
        float dx=x2-x1, dy=y2-y1, dz=z2-z1;
        float len=(float)Math.sqrt(dx*dx+dy*dy+dz*dz);
        if(len==0) return;
        v.method_22918(m,x1,y1,z1).method_22915(r,g,b,1f).method_22914(dx/len,dy/len,dz/len);
        v.method_22918(m,x2,y2,z2).method_22915(r,g,b,1f).method_22914(dx/len,dy/len,dz/len);
    }
}